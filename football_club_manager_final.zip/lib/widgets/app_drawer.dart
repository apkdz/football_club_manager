import 'package:flutter/material.dart';
import '../screens/dashboard_screen.dart';
import '../screens/calendar_screen.dart';
import '../screens/players_screen.dart';
import '../screens/absences_screen.dart';
import '../screens/subscriptions_screen.dart';
import '../screens/news_screen.dart';
import '../screens/ranking_screen.dart'; // تم إضافته

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.red),
            child: Text('نادي كرة القدم',
                style: TextStyle(color: Colors.white, fontSize: 24)),
          ),
          _buildDrawerItem(context, 'لوحة التحكم', const DashboardScreen()),
          _buildDrawerItem(context, 'البرنامج', const CalendarScreen()),
          _buildDrawerItem(context, 'اللاعبون', const PlayersScreen()),
          _buildDrawerItem(context, 'الغيابات', const AbsencesScreen()),
          _buildDrawerItem(context, 'الاشتراكات', const SubscriptionsScreen()),
          _buildDrawerItem(context, 'الأخبار', const NewsScreen()),
          _buildDrawerItem(context, 'ترتيب النقاط', const RankingScreen()), // جديد
        ],
      ),
    );
  }

  Widget _buildDrawerItem(BuildContext context, String title, Widget screen) {
    return ListTile(
      title: Text(title),
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
      },
    );
  }
}