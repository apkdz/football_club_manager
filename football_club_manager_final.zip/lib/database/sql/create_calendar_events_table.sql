CREATE TABLE IF NOT EXISTS calendar_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  date TEXT NOT NULL,
  type TEXT CHECK(type IN ('تدريب', 'مباراة', 'حدث')) NOT NULL DEFAULT 'حدث'
);