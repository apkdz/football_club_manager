
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'club_manager.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
  await db.execute('''
    CREATE TABLE players (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      category TEXT,
      rfid_code TEXT
    )
  ''');

  await db.execute('''
    CREATE TABLE absences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id INTEGER,
      date TEXT,
      reason TEXT
    )
  ''');

  await db.execute('''
    CREATE TABLE attendances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id INTEGER,
      date TEXT,
      method TEXT
    )
  ''');

  await db.execute('''
    CREATE TABLE calendar_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      date TEXT,
      type TEXT,
      description TEXT
    )
  ''');

  await db.execute('''
    CREATE TABLE subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id INTEGER,
      start_date TEXT,
      end_date TEXT,
      amount REAL
    )
  ''');

  await db.execute('''
    CREATE TABLE player_scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      player_id INTEGER,
      score INTEGER DEFAULT 0
    )
  ''');
}
    await db.execute('''
      CREATE TABLE players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        category TEXT,
        rfid_code TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE absences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER,
        date TEXT,
        reason TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE attendances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER,
        date TEXT,
        method TEXT  -- يدوي أو RFID
      )
    ''');

    await db.execute('''
      CREATE TABLE calendar_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        date TEXT,
        type TEXT,  -- تدريب أو مباراة
        description TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER,
        start_date TEXT,
        end_date TEXT,
        amount REAL
      )
    ''');
  }
}
