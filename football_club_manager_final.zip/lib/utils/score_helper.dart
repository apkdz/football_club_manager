import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';

class ScoreHelper {
  final dbHelper = DatabaseHelper();

  Future<void> addAttendancePoints(int playerId, {bool onTime = true}) async {
    final db = await dbHelper.database;

    await _ensurePlayerScoreExists(db, playerId);

    int points = 2; // حضور
    if (onTime) points += 1; // التزام

    await db.rawUpdate('''
      UPDATE player_scores SET score = score + ? WHERE player_id = ?
    ''', [points, playerId]);
  }

  Future<void> addGoodPerformancePoints(int playerId) async {
    final db = await dbHelper.database;
    await _ensurePlayerScoreExists(db, playerId);
    await db.rawUpdate('''
      UPDATE player_scores SET score = score + 3 WHERE player_id = ?
    ''', [playerId]);
  }

  Future<void> deductAbsencePoints(int playerId) async {
    final db = await dbHelper.database;
    await _ensurePlayerScoreExists(db, playerId);
    await db.rawUpdate('''
      UPDATE player_scores SET score = score - 2 WHERE player_id = ?
    ''', [playerId]);
  }

  Future<void> _ensurePlayerScoreExists(Database db, int playerId) async {
    final existing = await db.rawQuery('SELECT * FROM player_scores WHERE player_id = ?', [playerId]);
    if (existing.isEmpty) {
      await db.insert('player_scores', {'player_id': playerId, 'score': 0});
    }
  }

  Future<List<Map<String, dynamic>>> getRankings() async {
    final db = await dbHelper.database;
    return await db.rawQuery('''
      SELECT players.name, player_scores.score
      FROM player_scores
      JOIN players ON players.id = player_scores.player_id
      ORDER BY player_scores.score DESC
    ''');
  }
}