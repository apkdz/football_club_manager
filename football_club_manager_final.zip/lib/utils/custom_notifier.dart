import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import 'notification_helper.dart';

class CustomNotifier {
  /// إشعار فوري للغياب
  static Future<void> notifyAbsence(String playerName) async {
    await NotificationHelper._notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'تسجيل غياب',
      'تم تسجيل غياب اللاعب $playerName.',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'absence_channel',
          'إشعارات الغياب',
          channelDescription: 'تنبيهات عند تسجيل غيابات',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
    );
  }

  /// إشعار مجدول لتنبيه بانتهاء الاشتراك بعد 3 أيام
  static Future<void> notifySubscriptionExpiring({
    required int id,
    required String playerName,
    required DateTime expiryDate,
  }) async {
    final notifyTime = expiryDate.subtract(Duration(days: 3));
    if (notifyTime.isBefore(DateTime.now())) return;

    await NotificationHelper._notificationsPlugin.zonedSchedule(
      id,
      'تنبيه اشتراك',
      'اقترب موعد تجديد الاشتراك للاعب $playerName (3 أيام متبقية).',
      tz.TZDateTime.from(notifyTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'subscription_channel',
          'إشعارات الاشتراكات',
          channelDescription: 'تنبيهات قرب انتهاء الاشتراك',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.dateAndTime,
    );
  }
}