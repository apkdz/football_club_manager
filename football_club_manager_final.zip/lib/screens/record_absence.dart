import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/database_helper.dart';

class RecordAbsenceScreen extends StatefulWidget {
  @override
  _RecordAbsenceScreenState createState() => _RecordAbsenceScreenState();
}

class _RecordAbsenceScreenState extends State<RecordAbsenceScreen> {
  List<Map<String, dynamic>> players = [];
  int? selectedPlayerId;
  DateTime selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    fetchPlayers();
  }

  Future<void> fetchPlayers() async {
    final data = await DatabaseHelper().getPlayers();
    setState(() {
      players = data;
    });
  }

  Future<void> recordAbsence() async {
    if (selectedPlayerId == null) return;
    String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate);
    await DatabaseHelper().recordAbsence(selectedPlayerId!, formattedDate, "غياب يدوي");
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('تم تسجيل الغياب بنجاح!'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تسجيل غياب يدوي'), backgroundColor: Colors.black),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField<int>(
              value: selectedPlayerId,
              decoration: InputDecoration(labelText: 'اختر اللاعب'),
              items: players.map((player) {
                return DropdownMenuItem<int>(
                  value: player['id'],
                  child: Text(player['name']),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedPlayerId = value;
                });
              },
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text('التاريخ: ${DateFormat('yyyy-MM-dd').format(selectedDate)}',
                    style: TextStyle(fontSize: 16)),
                IconButton(
                  icon: Icon(Icons.calendar_today),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (picked != null) {
                      setState(() {
                        selectedDate = picked;
                      });
                    }
                  },
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: recordAbsence,
              child: Text('تسجيل الغياب'),
            ),
          ],
        ),
      ),
    );
  }
}