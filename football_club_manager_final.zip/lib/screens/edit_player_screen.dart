import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';

class EditPlayerScreen extends StatefulWidget {
  final int? playerId;

  const EditPlayerScreen({this.playerId});

  @override
  _EditPlayerScreenState createState() => _EditPlayerScreenState();
}

class _EditPlayerScreenState extends State<EditPlayerScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  int? _selectedTeamId;
  List<Map<String, dynamic>> _teams = [];

  @override
  void initState() {
    super.initState();
    fetchTeams();
    if (widget.playerId != null) {
      loadPlayerData(widget.playerId!);
    }
  }

  Future<void> fetchTeams() async {
    final db = await DatabaseHelper().database;
    final teams = await db.query('teams');
    setState(() {
      _teams = teams;
    });
  }

  Future<void> loadPlayerData(int id) async {
    final db = await DatabaseHelper().database;
    final data = await db.query('players', where: 'id = ?', whereArgs: [id]);
    if (data.isNotEmpty) {
      _nameController.text = data.first['name'];
      _selectedTeamId = data.first['team_id'];
      setState(() {});
    }
  }

  Future<void> savePlayer() async {
    if (!_formKey.currentState!.validate()) return;
    final db = await DatabaseHelper().database;
    final name = _nameController.text.trim();

    if (widget.playerId == null) {
      await db.insert('players', {
        'name': name,
        'team_id': _selectedTeamId,
      });
    } else {
      await db.update(
        'players',
        {'name': name, 'team_id': _selectedTeamId},
        where: 'id = ?',
        whereArgs: [widget.playerId],
      );
    }
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.playerId == null ? 'إضافة لاعب' : 'تعديل لاعب')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'اسم اللاعب'),
                validator: (value) => value == null || value.isEmpty ? 'يرجى إدخال الاسم' : null,
              ),
              DropdownButtonFormField<int>(
                value: _selectedTeamId,
                items: _teams.map((team) {
                  return DropdownMenuItem<int>(
                    value: team['id'],
                    child: Text(team['name']),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'الفريق'),
                onChanged: (value) => setState(() => _selectedTeamId = value),
                validator: (value) => value == null ? 'يرجى اختيار فريق' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: savePlayer,
                child: Text('حفظ'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}