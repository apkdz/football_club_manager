import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/database_helper.dart';

class SubscriptionsScreen extends StatefulWidget {
  @override
  _SubscriptionsScreenState createState() => _SubscriptionsScreenState();
}

class _SubscriptionsScreenState extends State<SubscriptionsScreen> {
  List<Map<String, dynamic>> players = [];
  String currentMonth = DateFormat('yyyy-MM').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    fetchPlayers();
  }

  Future<void> fetchPlayers() async {
    final data = await DatabaseHelper().getPlayers();
    setState(() {
      players = data;
    });
  }

  Future<void> updatePayment(int playerId, bool paid) async {
    await DatabaseHelper().updateSubscription(playerId, currentMonth, paid);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(paid ? 'تم تأكيد الدفع' : 'تم تعيين كغير مدفوع'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الاشتراكات - $currentMonth'), backgroundColor: Colors.black),
      body: ListView.builder(
        itemCount: players.length,
        itemBuilder: (context, index) {
          final player = players[index];
          return Card(
            child: ListTile(
              title: Text(player['name']),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.check_circle, color: Colors.green),
                    onPressed: () => updatePayment(player['id'], true),
                  ),
                  IconButton(
                    icon: Icon(Icons.cancel, color: Colors.red),
                    onPressed: () => updatePayment(player['id'], false),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}