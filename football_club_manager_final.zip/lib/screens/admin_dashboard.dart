import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';

class AdminDashboardScreen extends StatefulWidget {
  @override
  _AdminDashboardScreenState createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int totalPlayers = 0;
  int todaysAbsences = 0;
  int paidSubscriptions = 0;
  int unpaidSubscriptions = 0;
  List<Map<String, dynamic>> topAbsentPlayers = [];

  @override
  void initState() {
    super.initState();
    fetchDashboardData();
  }

  Future<void> fetchDashboardData() async {
    final db = await DatabaseHelper().database;
    final today = DateTime.now().toIso8601String().split("T")[0];

    totalPlayers = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM players')) ?? 0;
    todaysAbsences = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM absences WHERE date LIKE '$today%'")) ?? 0;
    paidSubscriptions = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM subscriptions WHERE is_paid = 1")) ?? 0;
    unpaidSubscriptions = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM subscriptions WHERE is_paid = 0")) ?? 0;

    topAbsentPlayers = await db.rawQuery(
      "SELECT players.name, COUNT(absences.id) as total_absences "
      "FROM absences "
      "JOIN players ON absences.player_id = players.id "
      "GROUP BY absences.player_id "
      "ORDER BY total_absences DESC "
      "LIMIT 5"
    );

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("لوحة التحكم")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            DashboardTile(title: "عدد اللاعبين", value: totalPlayers.toString()),
            DashboardTile(title: "غيابات اليوم", value: todaysAbsences.toString()),
            DashboardTile(title: "اشتراكات مدفوعة", value: paidSubscriptions.toString()),
            DashboardTile(title: "اشتراكات غير مدفوعة", value: unpaidSubscriptions.toString()),
            SizedBox(height: 20),
            Text("أكثر اللاعبين غيابًا:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...topAbsentPlayers.map((p) => ListTile(
              title: Text(p['name']),
              trailing: Text("${p['total_absences']} مرة"),
            )).toList()
          ],
        ),
      ),
    );
  }
}

class DashboardTile extends StatelessWidget {
  final String title;
  final String value;

  const DashboardTile({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.red[900],
      child: ListTile(
        title: Text(title, style: TextStyle(color: Colors.white)),
        trailing: Text(value, style: TextStyle(color: Colors.yellow, fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }
}