import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:io';
import 'package:path/path.dart' as path;
import '../utils/database_helper.dart';

class PlayerDocumentsScreen extends StatefulWidget {
  final int playerId;
  final String playerName;

  const PlayerDocumentsScreen({required this.playerId, required this.playerName});

  @override
  _PlayerDocumentsScreenState createState() => _PlayerDocumentsScreenState();
}

class _PlayerDocumentsScreenState extends State<PlayerDocumentsScreen> {
  List<Map<String, dynamic>> documents = [];

  @override
  void initState() {
    super.initState();
    fetchDocuments();
  }

  Future<void> fetchDocuments() async {
    final db = await DatabaseHelper().database;
    documents = await db.query(
      'documents',
      where: 'player_id = ?',
      whereArgs: [widget.playerId],
      orderBy: 'uploaded_at DESC',
    );
    setState(() {});
  }

  Future<void> pickAndSaveFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.single.path != null) {
      final pickedFile = File(result.files.single.path!);
      final appDir = await getApplicationDocumentsDirectory();
      final docDir = Directory('${appDir.path}/documents');
      if (!await docDir.exists()) await docDir.create(recursive: true);

      final fileName = path.basename(pickedFile.path);
      final newPath = path.join(docDir.path, fileName);
      await pickedFile.copy(newPath);

      final db = await DatabaseHelper().database;
      await db.insert('documents', {
        'player_id': widget.playerId,
        'name': fileName,
        'file_path': newPath,
        'uploaded_at': DateTime.now().toIso8601String(),
      });

      fetchDocuments();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("وثائق ${widget.playerName}")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: pickAndSaveFile,
              icon: Icon(Icons.upload_file),
              label: Text("رفع وثيقة"),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: documents.length,
                itemBuilder: (context, index) {
                  final doc = documents[index];
                  return ListTile(
                    leading: Icon(Icons.insert_drive_file, color: Colors.black),
                    title: Text(doc['name']),
                    subtitle: Text("تم الرفع: ${doc['uploaded_at'].toString().substring(0, 10)}"),
                    onTap: () => openFile(doc['file_path']),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  void openFile(String filePath) async {
    if (await File(filePath).exists()) {
      // بإمكانك استخدام أي مكتبة مثل open_file لفتح الملف مباشرة
      // OpenFile.open(filePath);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("فتح الملف: $filePath")));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("الملف غير موجود")));
    }
  }
}