import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';

class TeamsScreen extends StatefulWidget {
  @override
  _TeamsScreenState createState() => _TeamsScreenState();
}

class _TeamsScreenState extends State<TeamsScreen> {
  List<Map<String, dynamic>> teams = [];
  final TextEditingController _controller = TextEditingController();
  int? _editingTeamId;

  @override
  void initState() {
    super.initState();
    fetchTeams();
  }

  Future<void> fetchTeams() async {
    final db = await DatabaseHelper().database;
    teams = await db.query('teams', orderBy: 'id DESC');
    setState(() {});
  }

  Future<void> saveTeam() async {
    final db = await DatabaseHelper().database;
    final name = _controller.text.trim();
    if (name.isEmpty) return;

    if (_editingTeamId == null) {
      await db.insert('teams', {'name': name});
    } else {
      await db.update('teams', {'name': name}, where: 'id = ?', whereArgs: [_editingTeamId]);
    }

    _controller.clear();
    _editingTeamId = null;
    fetchTeams();
  }

  Future<void> deleteTeam(int id) async {
    final db = await DatabaseHelper().database;
    await db.delete('teams', where: 'id = ?', whereArgs: [id]);
    fetchTeams();
  }

  void startEditing(Map<String, dynamic> team) {
    _controller.text = team['name'];
    _editingTeamId = team['id'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إدارة الفرق')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(labelText: 'اسم الفريق'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.save),
                  onPressed: saveTeam,
                ),
              ],
            ),
            Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: teams.length,
                itemBuilder: (context, index) {
                  final team = teams[index];
                  return ListTile(
                    title: Text(team['name']),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () => startEditing(team),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => deleteTeam(team['id']),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}