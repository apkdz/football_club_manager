import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:intl/intl.dart';
import '../utils/database_helper.dart';

class BluetoothRFIDScreen extends StatefulWidget {
  @override
  _BluetoothRFIDScreenState createState() => _BluetoothRFIDScreenState();
}

class _BluetoothRFIDScreenState extends State<BluetoothRFIDScreen> {
  FlutterBluePlus flutterBlue = FlutterBluePlus.instance;
  BluetoothDevice? connectedDevice;
  List<BluetoothService> services = [];
  String lastReadRFID = '';

  @override
  void initState() {
    super.initState();
    startScan();
  }

  void startScan() {
    flutterBlue.startScan(timeout: Duration(seconds: 5));

    flutterBlue.scanResults.listen((results) {
      for (ScanResult r in results) {
        if (r.device.name.toLowerCase().contains("rfid")) {
          connectToDevice(r.device);
          flutterBlue.stopScan();
          break;
        }
      }
    });
  }

  void connectToDevice(BluetoothDevice device) async {
    await device.connect();
    connectedDevice = device;
    services = await device.discoverServices();

    for (BluetoothService service in services) {
      for (BluetoothCharacteristic characteristic in service.characteristics) {
        if (characteristic.properties.notify) {
          await characteristic.setNotifyValue(true);
          characteristic.value.listen((value) {
            String data = utf8.decode(value).trim();
            if (data.isNotEmpty && data != lastReadRFID) {
              lastReadRFID = data;
              registerRFIDAbsence(data);
            }
          });
        }
      }
    }

    setState(() {});
  }

  Future<void> registerRFIDAbsence(String rfidCode) async {
    final db = await DatabaseHelper().db;
    final playerResult = await db.query('players', where: 'rfid = ?', whereArgs: [rfidCode]);

    if (playerResult.isNotEmpty) {
      final player = playerResult.first;
      final playerId = player['id'];
      final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

      await DatabaseHelper().recordAbsence(playerId, today, "غياب عبر RFID");

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم تسجيل غياب اللاعب: ${player['name']}')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('لم يتم العثور على لاعب بهذا المعرف: $rfidCode')),
      );
    }
  }

  @override
  void dispose() {
    if (connectedDevice != null) connectedDevice!.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('قارئ RFID عبر البلوتوث'), backgroundColor: Colors.black),
      body: Center(
        child: connectedDevice == null
            ? Text('جارٍ البحث عن الجهاز...', style: TextStyle(fontSize: 18))
            : Text('متصل بـ: ${connectedDevice!.name}', style: TextStyle(fontSize: 18)),
      ),
    );
  }
}