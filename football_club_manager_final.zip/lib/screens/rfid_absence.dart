import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:async';

class RFIDAbsenceScreen extends StatefulWidget {
  @override
  _RFIDAbsenceScreenState createState() => _RFIDAbsenceScreenState();
}

class _RFIDAbsenceScreenState extends State<RFIDAbsenceScreen> {
  bool scanning = false;
  String? lastRFID;
  String? detectedPlayer;
  Timer? _scanTimer;

  final Map<String, String> rfidDatabase = {
    '123456': 'Ali Ben Salah',
    '234567': 'Youssef Trabelsi',
    '345678': 'Omar Gharbi',
    '456789': 'Karim Ayari',
  };

  void startScanSimulation() {
    _scanTimer = Timer.periodic(Duration(seconds: 5), (timer) {
      final fakeRFIDs = ['123456', '234567', '345678', '456789'];
      fakeRFIDs.shuffle();
      String scannedRFID = fakeRFIDs.first;
      setState(() {
        lastRFID = scannedRFID;
        detectedPlayer = rfidDatabase[scannedRFID];
      });

      if (detectedPlayer != null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              'تم تسجيل غياب ${detectedPlayer!} بتاريخ ${DateFormat('yyyy-MM-dd').format(DateTime.now())}'),
        ));
      }
    });
  }

  void stopScanSimulation() {
    _scanTimer?.cancel();
  }

  @override
  void dispose() {
    stopScanSimulation();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الغيابات عبر RFID'), backgroundColor: Colors.black),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.rss_feed, size: 80, color: scanning ? Colors.green : Colors.grey),
            SizedBox(height: 20),
            Text(scanning ? 'جارٍ المسح...' : 'المسح متوقف',
                style: TextStyle(fontSize: 20, color: Colors.white)),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(scanning ? Icons.stop : Icons.play_arrow),
              label: Text(scanning ? 'إيقاف المسح' : 'بدء المسح'),
              onPressed: () {
                setState(() {
                  scanning = !scanning;
                  if (scanning) {
                    startScanSimulation();
                  } else {
                    stopScanSimulation();
                  }
                });
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: scanning ? Colors.red : Colors.green),
            ),
            SizedBox(height: 30),
            if (lastRFID != null)
              Column(
                children: [
                  Text('آخر بطاقة مقروءة: $lastRFID',
                      style: TextStyle(color: Colors.white)),
                  Text('اللاعب: ${detectedPlayer ?? 'غير معروف'}',
                      style: TextStyle(color: Colors.white)),
                ],
              )
          ],
        ),
      ),
    );
  }
}