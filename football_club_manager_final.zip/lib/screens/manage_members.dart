import 'package:flutter/material.dart';

class ManageMembersScreen extends StatefulWidget {
  @override
  _ManageMembersScreenState createState() => _ManageMembersScreenState();
}

class _ManageMembersScreenState extends State<ManageMembersScreen> {
  String selectedCategory = 'All';

  final List<Map<String, String>> members = [
    {'name': 'Ali Ben Salah', 'category': 'U11', 'status': 'مدفوع'},
    {'name': 'Youssef Trabelsi', 'category': 'U13', 'status': 'غير مدفوع'},
    {'name': 'Omar Gharbi', 'category': 'U15', 'status': 'مدفوع'},
    {'name': 'Karim Ayari', 'category': 'U11', 'status': 'غير مدفوع'},
  ];

  @override
  Widget build(BuildContext context) {
    List<Map<String, String>> filteredMembers = selectedCategory == 'All'
        ? members
        : members.where((m) => m['category'] == selectedCategory).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('إدارة الأعضاء'),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButton<String>(
              dropdownColor: Colors.black,
              value: selectedCategory,
              items: ['All', 'U9', 'U11', 'U13', 'U15', 'U17', 'U19', 'أكابر']
                  .map((cat) => DropdownMenuItem<String>(
                        value: cat,
                        child: Text(cat, style: TextStyle(color: Colors.white)),
                      ))
                  .toList(),
              onChanged: (val) {
                setState(() {
                  selectedCategory = val!;
                });
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredMembers.length,
              itemBuilder: (context, index) {
                final member = filteredMembers[index];
                return Card(
                  color: Colors.grey[850],
                  child: ListTile(
                    title: Text(member['name']!, style: TextStyle(color: Colors.white)),
                    subtitle: Text('الفئة: ${member['category']!}', style: TextStyle(color: Colors.white70)),
                    trailing: Text(member['status']!,
                        style: TextStyle(
                            color: member['status'] == 'مدفوع' ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold)),
                    onTap: () {
                      setState(() {
                        member['status'] =
                            member['status'] == 'مدفوع' ? 'غير مدفوع' : 'مدفوع';
                      });
                    },
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}