import 'package:flutter/material.dart';
import '../utils/database_helper.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int playerCount = 0;
  int absencesThisMonth = 0;
  int trainings = 0;
  int matches = 0;
  int expiredSubscriptions = 0;
  double attendanceRate = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final db = await DatabaseHelper().database;
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1).toIso8601String();
    final today = now.toIso8601String();

    final p = await db.rawQuery('SELECT COUNT(*) as count FROM players');
    final a = await db.rawQuery('SELECT COUNT(*) as count FROM absences WHERE date >= ?', [startOfMonth]);
    final t = await db.rawQuery("SELECT COUNT(*) as count FROM calendar_events WHERE type = 'تدريب'");
    final m = await db.rawQuery("SELECT COUNT(*) as count FROM calendar_events WHERE type = 'مباراة'");
    final s = await db.rawQuery("SELECT COUNT(*) as count FROM subscriptions WHERE end_date < ?", [today]);

    final totalSessions = await db.rawQuery("SELECT COUNT(*) as count FROM calendar_events");
    final totalAttendances = await db.rawQuery("SELECT COUNT(*) as count FROM attendances");

    setState(() {
      playerCount = p.first['count'] as int;
      absencesThisMonth = a.first['count'] as int;
      trainings = t.first['count'] as int;
      matches = m.first['count'] as int;
      expiredSubscriptions = s.first['count'] as int;
      attendanceRate = totalSessions.first['count'] == 0 || playerCount == 0
          ? 0
          : (totalAttendances.first['count'] as int) /
              (totalSessions.first['count'] as int * playerCount) * 100;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            _StatCard(title: 'عدد اللاعبين', value: '$playerCount', color: Colors.red),
            _StatCard(title: 'الغيابات هذا الشهر', value: '$absencesThisMonth', color: Colors.yellow),
            _StatCard(title: 'عدد التدريبات', value: '$trainings', color: Colors.black),
            _StatCard(title: 'عدد المباريات', value: '$matches', color: Colors.redAccent),
            _StatCard(title: 'الاشتراكات المنتهية', value: '$expiredSubscriptions', color: Colors.orange),
            _StatCard(title: 'نسبة الحضور', value: '${attendanceRate.toStringAsFixed(1)}%', color: Colors.green),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final Color color;

  const _StatCard({
    required this.title,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color.withOpacity(0.8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Center(
        child: ListTile(
          title: Text(
            value,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          subtitle: Text(
            title,
            style: const TextStyle(fontSize: 16, color: Colors.white),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}