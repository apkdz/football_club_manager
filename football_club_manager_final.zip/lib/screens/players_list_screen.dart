import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';
import 'edit_player_screen.dart';

class PlayersListScreen extends StatefulWidget {
  @override
  _PlayersListScreenState createState() => _PlayersListScreenState();
}

class _PlayersListScreenState extends State<PlayersListScreen> {
  List<Map<String, dynamic>> players = [];
  List<Map<String, dynamic>> teams = [];
  int? selectedTeamId;

  @override
  void initState() {
    super.initState();
    fetchTeams();
    fetchPlayers();
  }

  Future<void> fetchTeams() async {
    final db = await DatabaseHelper().database;
    teams = await db.query('teams');
    setState(() {});
  }

  Future<void> fetchPlayers() async {
    final db = await DatabaseHelper().database;
    final whereClause = selectedTeamId != null ? 'team_id = ?' : null;
    final whereArgs = selectedTeamId != null ? [selectedTeamId] : null;

    players = await db.query(
      'players',
      where: whereClause,
      whereArgs: whereArgs,
      orderBy: 'name',
    );
    setState(() {});
  }

  void openEditPlayer(int? id) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => EditPlayerScreen(playerId: id)),
    );
    if (result == true) fetchPlayers();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('اللاعبون'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => openEditPlayer(null),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButtonFormField<int>(
              value: selectedTeamId,
              decoration: InputDecoration(labelText: 'تصفية حسب الفريق'),
              items: [
                DropdownMenuItem(value: null, child: Text('الكل')),
                ...teams.map((team) => DropdownMenuItem(
                      value: team['id'],
                      child: Text(team['name']),
                    )),
              ],
              onChanged: (value) {
                setState(() => selectedTeamId = value);
                fetchPlayers();
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: players.length,
              itemBuilder: (context, index) {
                final player = players[index];
                return ListTile(
                  title: Text(player['name']),
                  subtitle: Text('فريق: ${teams.firstWhere((t) => t['id'] == player['team_id'], orElse: () => {'name': 'غير محدد'})['name']}'),
                  trailing: IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () => openEditPlayer(player['id']),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}