import 'package:flutter/material.dart';
import 'manage_members.dart';
import 'record_absence.dart';
import 'calendar.dart';
import 'subscriptions.dart';
import 'rfid_absence.dart';


class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        backgroundColor: Colors.black,
        actions: [Icon(Icons.notifications)],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(
              children: [
                _buildCard("U13\nAttendance: 24", Colors.red),
                _buildCard("Absences\nToday: 3", Colors.yellow[700]!),
              ],
            ),
            Row(
              children: [
                _buildCard("Expired\nSubscriptions: 7", Colors.grey[850]!),
                _buildCard("Alerts", Colors.red[900]!),
              ],
            ),
            SizedBox(height: 20),
            ListTile(
              leading: Icon(Icons.people),
              title: Text('Manage Members'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ManageMembersScreen()),
              ),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
            ListTile(
              leading: Icon(Icons.schedule),
              title: Text('Manage Schedule'),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
            ListTile(
              leading: Icon(Icons.calendar_today),
              title: Text('البرنامج'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CalendarScreen()),
              ),
            ),
            ListTile(
              leading: Icon(Icons.payment),
              title: Text('الاشتراكات'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SubscriptionsScreen()),
              ),
            ),
            ListTile(
              leading: Icon(Icons.rss_feed),
              title: Text('تسجيل الغيابات عبر RFID'),
              trailing: Icon(Icons.arrow_forward_ios),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RFIDAbsenceScreen()),
              ),
            ),
            ListTile(
              leading: Icon(Icons.assignment),
              title: Text('Record Absences'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => RecordAbsenceScreen()),
              ),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(String text, Color color) {
    return Expanded(
      child: Container(
        height: 100,
        margin: EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}