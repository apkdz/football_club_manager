import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/database_helper.dart';

class ParentDashboardScreen extends StatefulWidget {
  final String playerRFID;
  ParentDashboardScreen({required this.playerRFID});

  @override
  _ParentDashboardScreenState createState() => _ParentDashboardScreenState();
}

class _ParentDashboardScreenState extends State<ParentDashboardScreen> {
  Map<String, dynamic>? player;
  int totalAbsences = 0;
  bool subscriptionPaid = false;
  String currentMonth = DateFormat('yyyy-MM').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    fetchPlayerData();
  }

  Future<void> fetchPlayerData() async {
    final db = await DatabaseHelper().db;
    final playerResult = await db.query(
      'players',
      where: 'rfid = ?',
      whereArgs: [widget.playerRFID],
    );

    if (playerResult.isNotEmpty) {
      final playerData = playerResult.first;
      final playerId = playerData['id'];

      final absenceResult = await db.query(
        'absences',
        where: 'player_id = ?',
        whereArgs: [playerId],
      );

      final subscriptionResult = await db.query(
        'subscriptions',
        where: 'player_id = ? AND month = ?',
        whereArgs: [playerId, currentMonth],
      );

      setState(() {
        player = playerData;
        totalAbsences = absenceResult.length;
        subscriptionPaid = subscriptionResult.isNotEmpty && subscriptionResult.first['paid'] == 1;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('لوحة ولي الأمر'), backgroundColor: Colors.black),
      body: player == null
          ? Center(child: Text('جارٍ تحميل البيانات...', style: TextStyle(color: Colors.white)))
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الاسم: ${player!['name']}', style: TextStyle(fontSize: 20, color: Colors.white)),
                  SizedBox(height: 12),
                  Text('عدد الغيابات: $totalAbsences', style: TextStyle(fontSize: 18, color: Colors.white)),
                  SizedBox(height: 12),
                  Text('الاشتراك ($currentMonth): ${subscriptionPaid ? 'مدفوع' : 'غير مدفوع'}',
                      style: TextStyle(fontSize: 18, color: subscriptionPaid ? Colors.green : Colors.red)),
                  SizedBox(height: 20),
                  Text('آخر الأخبار:', style: TextStyle(fontSize: 18, color: Colors.yellow)),
                  SizedBox(height: 8),
                  Text('- تدريب يوم الجمعة الساعة 17:00.', style: TextStyle(color: Colors.white)),
                  Text('- مباراة ودية الأحد القادم.', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
    );
  }
}