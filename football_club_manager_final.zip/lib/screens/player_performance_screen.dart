import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';

class PlayerPerformanceScreen extends StatefulWidget {
  final int playerId;
  final String playerName;

  const PlayerPerformanceScreen({required this.playerId, required this.playerName});

  @override
  _PlayerPerformanceScreenState createState() => _PlayerPerformanceScreenState();
}

class _PlayerPerformanceScreenState extends State<PlayerPerformanceScreen> {
  final TextEditingController _noteController = TextEditingController();
  double _rating = 3.0;
  List<Map<String, dynamic>> performances = [];

  @override
  void initState() {
    super.initState();
    fetchPerformances();
  }

  Future<void> fetchPerformances() async {
    final db = await DatabaseHelper().database;
    performances = await db.query(
      'performances',
      where: 'player_id = ?',
      whereArgs: [widget.playerId],
      orderBy: 'date DESC',
    );
    setState(() {});
  }

  Future<void> addPerformance() async {
    final db = await DatabaseHelper().database;
    await db.insert('performances', {
      'player_id': widget.playerId,
      'rating': _rating,
      'note': _noteController.text,
      'date': DateTime.now().toIso8601String(),
    });
    _noteController.clear();
    _rating = 3.0;
    fetchPerformances();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("سجل أداء ${widget.playerName}")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("إضافة تقييم جديد", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Slider(
              value: _rating,
              min: 1,
              max: 5,
              divisions: 4,
              label: _rating.toString(),
              onChanged: (val) => setState(() => _rating = val),
            ),
            TextField(
              controller: _noteController,
              decoration: InputDecoration(labelText: "ملاحظة اختيارية"),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: addPerformance,
              child: Text("حفظ التقييم"),
            ),
            Divider(height: 30),
            Text("السجل السابق", style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: performances.length,
                itemBuilder: (context, index) {
                  final p = performances[index];
                  return ListTile(
                    leading: Icon(Icons.star, color: Colors.amber),
                    title: Text("تقييم: ${p['rating']}"),
                    subtitle: Text(p['note'] ?? ''),
                    trailing: Text(p['date'].toString().substring(0, 10)),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}