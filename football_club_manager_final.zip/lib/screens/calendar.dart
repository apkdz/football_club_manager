import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CalendarScreen extends StatelessWidget {
  final List<Map<String, String>> events = [
    {'type': 'مباراة', 'date': '2025-05-20', 'details': 'ضد نادي النجم الساحلي - U13'},
    {'type': 'تدريب', 'date': '2025-05-22', 'details': 'ملعب النادي - U13'},
    {'type': 'مباراة', 'date': '2025-05-27', 'details': 'ضد نادي قرطاج - U15'},
    {'type': 'تدريب', 'date': '2025-05-29', 'details': 'القاعة المغطاة - U15'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('البرنامج'), backgroundColor: Colors.black),
      body: ListView.builder(
        itemCount: events.length,
        itemBuilder: (context, index) {
          final event = events[index];
          return ListTile(
            leading: Icon(event['type'] == 'مباراة' ? Icons.sports_soccer : Icons.fitness_center, color: Colors.white),
            title: Text('${event['type']} - ${event['date']}', style: TextStyle(color: Colors.white)),
            subtitle: Text(event['details']!, style: TextStyle(color: Colors.white70)),
          );
        },
      ),
    );
  }