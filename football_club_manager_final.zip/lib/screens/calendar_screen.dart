import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/database_helper.dart';

class CalendarScreen extends StatefulWidget {
  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Map<String, List<Map<String, dynamic>>> _events = {};

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    fetchEvents();
  }

  Future<void> fetchEvents() async {
    final db = await DatabaseHelper().database;
    final data = await db.query('calendar_events');
    _events = {};
    for (final event in data) {
      final date = event['date'];
      if (_events.containsKey(date)) {
        _events[date]!.add(event);
      } else {
        _events[date] = [event];
      }
    }
    setState(() {});
  }

  void _addEventDialog() {
    final _titleController = TextEditingController();
    final _descController = TextEditingController();
    String _selectedType = 'حدث';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('إضافة حدث'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'عنوان الحدث'),
            ),
            TextField(
              controller: _descController,
              decoration: InputDecoration(labelText: 'الوصف (اختياري)'),
            ),
            DropdownButtonFormField<String>(
              value: _selectedType,
              items: ['تدريب', 'مباراة', 'حدث'].map((type) {
                return DropdownMenuItem(value: type, child: Text(type));
              }).toList(),
              onChanged: (value) => _selectedType = value ?? 'حدث',
              decoration: InputDecoration(labelText: 'نوع الحدث'),
            )
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              final title = _titleController.text.trim();
              if (title.isEmpty || _selectedDay == null) return;

              final db = await DatabaseHelper().database;
              await db.insert('calendar_events', {
                'title': title,
                'description': _descController.text.trim(),
                'date': _selectedDay!.toIso8601String().substring(0, 10),
                'type': _selectedType
              });
              Navigator.pop(context);
              fetchEvents();
            },
            child: Text('حفظ'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedDateStr = _selectedDay!.toIso8601String().substring(0, 10);
    final selectedEvents = _events[selectedDateStr] ?? [];

    return Scaffold(
      appBar: AppBar(title: Text('التقويم الشهري')),
      body: Column(
        children: [
          TableCalendar(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            calendarFormat: CalendarFormat.month,
            eventLoader: (day) {
              final dateKey = day.toIso8601String().substring(0, 10);
              return _events[dateKey] ?? [];
            },
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('أحداث اليوم:', style: TextStyle(fontWeight: FontWeight.bold)),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: _addEventDialog,
                )
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: selectedEvents.length,
              itemBuilder: (context, index) {
                final event = selectedEvents[index];
                return ListTile(
                  title: Text(event['title']),
                  subtitle: Text('${event['type']} - ${event['description'] ?? ''}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}