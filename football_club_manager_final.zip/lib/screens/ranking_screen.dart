import 'package:flutter/material.dart';
import '../utils/score_helper.dart';

class RankingScreen extends StatefulWidget {
  const RankingScreen({super.key});

  @override
  State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen> {
  final ScoreHelper scoreHelper = ScoreHelper();
  List<Map<String, dynamic>> rankings = [];

  @override
  void initState() {
    super.initState();
    _loadRankings();
  }

  Future<void> _loadRankings() async {
    final data = await scoreHelper.getRankings();
    setState(() {
      rankings = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ترتيب اللاعبين')),
      body: ListView.builder(
        itemCount: rankings.length,
        itemBuilder: (context, index) {
          final item = rankings[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.redAccent,
              child: Text('${index + 1}', style: const TextStyle(color: Colors.white)),
            ),
            title: Text(item['name'] ?? ''),
            trailing: Text('${item['score']} نقطة',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          );
        },
      ),
    );
  }
}