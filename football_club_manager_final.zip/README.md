# Football Club Manager

تطبيق تسيير نادي كرة القدم باستخدام Flutter.
يدعم Android، iOS، والويب.

## الميزات

- واجهة إدارة النادي
- نشر برنامج المباريات والتدريبات
- تسجيل الغيابات يدويًا أو عبر RFID (Bluetooth)
- متابعة الاشتراكات الشهرية
- أخبار النادي
- واجهة خاصة لأولياء الأمور

## التشغيل

### المتطلبات
- Flutter SDK مثبت (https://flutter.dev/docs/get-started/install)
- Android Studio أو VS Code
- جهاز Android أو iOS أو متصفح Chrome

### الأوامر الأساسية
```bash
flutter pub get           # تثبيت الحزم
flutter run -d android    # تشغيل على أندرويد
flutter run -d ios        # تشغيل على iOS (من Mac فقط)
flutter run -d chrome     # تشغيل على الويب
```

### ملاحظات
- قارئ RFID يعمل فقط على Android و iOS (غير مدعوم في الويب).
- قاعدة البيانات محلية باستخدام SQLite.

## الاتصال
لأي استفسار أو تطوير إضافي، لا تتردد في التواصل مع المطور.